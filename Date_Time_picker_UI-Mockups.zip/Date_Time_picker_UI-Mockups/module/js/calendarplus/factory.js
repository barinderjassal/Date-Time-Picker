/**
 *
 * Created by Barinderjit Singh on 20/10/16.
 * Updated by Sumit Kumar Ray.
 * Description:
 *
 */
define([
    'angular',
    'moment',
    'module/js/calendarplus/calendarplus',
    'module/js/calendarplus/controller'
], function (angular, moment, template) {
    angular.module('CalendarPlus')
        .factory('CalendarFactory',['$q', '$http', function($q, $http) {
            var factoryObj = {
                validateDate: function (sampleDateString) {
                    var dateArr = sampleDateString.split('/'),
                        mm = dateArr[0],
                        dd = dateArr[1],
                        yy = dateArr[2];
                    if ((mm < 1 || mm > 12) || (dd < 1 || dd > 31)) {
                        alert('Please enter a valid date');
                        return false;

                    } else {
                        return true;
                    }
                },
                removeTime: function (date) {
                    return date.hour(0).minute(0).second(0).millisecond(0);
                },
                createMonth: function ($scope, start, month) {
                    $scope.weeks = [];
                    var done = false,
                        date = start.clone(), //momentObj i.e. start date on calndr i.e extreme left date.it can be of previous month
                        monthIndex = date.month(), //index of month of that extreme left date i.e for Jan it'll be 0
                        count = 0;
                    while (!done) {
                        $scope.weeks.push({ days: factoryObj.createWeek($scope, date.clone(), month) });
                        date.add(1, 'w');
                        done = count++ > 2 && monthIndex !== date.month();
                        monthIndex = date.month();
                    }
                
                },
                createWeek: function ($scope, date, month) {
                    // date contains the start date i.e extreme left date , a momentObj
                    // month contains the current date, Again momentObj
                    var days = [],
                        i;
                    for (i = 0; i < 7; i++) {
                        days.push({
                            name: date.format('dd').substring(0, 1), //S,M,T,W,T,F,S
                            number: date.date().toString().replace(/\b(\d{1})\b/g, '0$1'), // get date Number in string i.e 01,02,30
                            isCurrentMonth: date.month() === month.month(), //compare currentMonth from start.clone() & month.month()
                            isToday: date.isSame(new Date(), 'day'), 
                            //isSame is a method of moment. Second parameter will match all  units equal or larger. passing in "month" will check month and year. Passing in "day" will check day, month and year              
                            
                            

                            date: date // date contains the start date, extreme left, can be of previous month.
                        });
                        
                        date = date.clone();
                        date.add(1, 'd');
                       
                    }
                    return days;
                }                     
        }; // end of factory
            
        return factoryObj;
            
    }]);
})