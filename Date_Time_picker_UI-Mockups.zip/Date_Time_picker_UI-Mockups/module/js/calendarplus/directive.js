/**
 *
 * Created by Barinderjit Singh on 20/10/16.
 * Updated by Sumit Kumar Ray.
 * Description:
 *
 */

define([
    'angular',
    'moment',
    'text!module/template/template.html',
    'module/js/calendarplus/controller',
    'module/js/calendarplus/calendarplus'
], function (angular, moment, template) {
    angular.module('CalendarPlus').directive('calendar', [function () {
        return {
            restrict: 'EA',
            template: template,
            scope: {
                onMonthChange: '&', //callback Function  // Data can be passed as a function the & string literal
                dateFilter: '&',
                events: '=', // Data can be passed as an object using the = string literal
                dateValue: '=?',
                config: '=?'
            },
            controller: 'CalendarPlusController',
            link: function (scope, element, attrs) {
                scope.config.hidePicker = function(){
                   angular.element(element).parent().removeClass('show-picker');
            };
            }
        };
    }]);
});
