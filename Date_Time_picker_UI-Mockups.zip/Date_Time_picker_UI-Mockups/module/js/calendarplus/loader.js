/**
* Created by Vasvi Chawla on 6/11/15.
* Description:
*
*/
define([
    'module/js/calendarplus/directive'
], function () {
});