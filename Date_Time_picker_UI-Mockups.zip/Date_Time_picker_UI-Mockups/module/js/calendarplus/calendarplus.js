/**
 * Created by Vasvi Chawla on 6/11/15.
 * Description:
 *
 */

define([
    'angular'
], function (angular) {
    angular.module('CalendarPlus', []);
});
