/**
 * Created by Sumit Kumar Ray.
 * Description:
 *
 */
define([
    'angular',
    'moment',
    'module/js/calendarplus/calendarpluspopup/calendarpluspopup',
], function(angular, moment, template, factory) {
    angular.module('CalendarPlusPopup').controller('CalendarPlusPopupController', ['$scope', '$element', '$attrs', function($scope, $element, $attrs) {
		

    }]);
});