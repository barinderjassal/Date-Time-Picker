/**
 * Created by Barinderjit Singh on 28/12/2016
 * Description: CalendarPlus - QuarterPicker Module 
 *
 */

define([
    'angular',
], function(angular) {
    angular.module('CoreCalendar', ['CalendarPlus' ,'CalendarPlusPopup', 'TimePicker']);
});
