/**
 * Created by Barinderjit Singh on 28/12/2016
 * Description: Calendar - QuarterPicker Loader
 *
 */
define([
    'module/js/corecalendar',
    'module/js/calendarplus/loader',
	'module/js/calendarplus/calendarpluspopup/loader'
], function () {});
