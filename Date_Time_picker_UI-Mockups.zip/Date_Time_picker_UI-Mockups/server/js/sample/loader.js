/**
 * Created by Barinderjit Singh on 28/12/2016
 * Description: Sample Core Calendar Loader
 *
 */
define([
    'server/js/sample/sample',
    'server/js/sample/calendarplus/directive',
	'server/js/sample/calendarplus/calendarpluspopup/directive'
], function () {

});
