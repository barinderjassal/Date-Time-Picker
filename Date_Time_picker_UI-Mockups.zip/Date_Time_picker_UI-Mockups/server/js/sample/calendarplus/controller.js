/**
 * Created by Barinderjit Singh on 20/10/16.
 * Description:
 *
 */
define([
    'angular',
    'moment',
    'server/js/sample/calendarplus/sample'
], function (angular, moment) {
    angular.module('SampleCalendarView')
        .controller('SampleCalendarViewController', ['$scope', '$filter', function ($scope, $filter) {
			
            $scope.filter = function (date, month, year, day) {
                var i;
                $scope.filteredEvents = [];
                $scope.evtLength = 0;
                for (i = 0; i < $scope.events.length; i++) {
                    if (new Date($scope.events[i].start).getDate() === date) {
                        $scope.filteredEvents.push($scope.events[i]);
                        $scope.evtLength++;
                    }
                }
            };

            $scope.setMonth = function (monthindex, monthname, year) {
                $scope.month = monthindex;
                $scope.monthname = monthname;
                $scope.year = year;
                $scope.eventDates = [];
                $scope.filteredEvents = [];
                $scope.evtLength = 0;
                $scope.loadEvents(monthindex, year, $scope.calendar_id);
            };
           
            var date = new Date();
            /*
             * setDateValue is the date to passed from user to set calendar on that date.
             */
            $scope.setDateValue = moment(date).format('MM/DD/YYYY'); 
            //$scope.setDateValue = '10/20/2015';
            
            /* 
             * resetCalendar() function is used to reset the calendar on changing the view of the my events portlet on Bench end. 
             */
            $scope.calendarResetConfig = {
                setDateCal: function(val){
                   $scope.calDateVal=val;
                }
            };
            
            $scope.resetCalendar = function () {
                $scope.calendarResetConfig.resetCalendar();
            };
            
            var dataInitial = {
                    'event_types': {
                        'event_type': {
                            'content': 'All Employee Meeting',
                            'id': '54750EAC957869B6E04031033A083365',
                            'color': '#FEEDDC'
                        }
                    },
                    'events': {
                        'event': 
                        [{
                            'start_date': '2016-07-16',
                            'calendars': '51C92673751653FCE04031033A083A9D'
                        }, {
                            'start_date': '2016-07-31',
                            'calendars': '51C92673751653FCE04031033A083A9D'
                        }, {
                            'start_date': '2016-07-02',
                            'calendars': '51C92673751653FCE04031033A083A9D'
                        }],
                        'no_result': 3
                    }
                },
                data = dataInitial.events.event;

            $scope.eventDates = [];
            $scope.events = data;

            $scope.loadEvents = function (month, year, calendar) {
                if (data.length) {
                    $scope.filteredEvents = $scope.events;
                    $scope.evtLength = data.length;
                    $scope.noEventClass = '';
                    var i, stDay;
                    for (i = 0; i < data.length; i++) {
                        stDay = moment(data[i].start_date.replace(/\b(\d{1})\b/g, '0$1')).date();
                        $scope.eventDates.push(stDay);                        
                    } 
                } else {
                    $scope.calendarClass = 'calendarVisible';
                    //$scope.noEventClass = 'no-event';
                }
            };

            $scope.setMonth(11, "Dec\'15", 2015);
            
            /*
            ================================================
            */
            
            $scope.filterPopup = function (date, month, year, day) {
                var i;
                $scope.filteredEventsPopup = [];
                $scope.evtLength = 0;
                for (i = 0; i < $scope.events.length; i++) {
                    if (new Date($scope.events[i].start).getDate() === date) {
                        $scope.filteredEventsPopup.push($scope.events[i]);
                        $scope.evtLength++;
                    }
                }
            };

            $scope.setMonthPopup = function (monthindex, monthname, year) {
                $scope.monthPopup = monthindex;
                $scope.monthnamePopup = monthname;
                $scope.yearPopup = year;
                $scope.eventDatesPopup = [];
                $scope.filteredEventsPopup = [];
                $scope.evtLengthPopup = 0;
                $scope.loadEventsPopup(monthindex, year, $scope.calendar_id);
            };
            $scope.calendarResetConfigPopup = {
                setDateCal: function(val){
                   $scope.calDateValPop=val;
                }   
            };
            var datePopup = new Date();
            /*
             * setDateValue is the date to passed from user to set calendar on that date.
             */
            $scope.setDateValuePopup = moment(datePopup).format('MM/DD/YYYY'); 
            //$scope.setDateValue = '10/20/2015';
            
            /* 
             * resetCalendar() function is used to reset the calendar on changing the view of the my events portlet on Bench end. 
             */
           
            var dataInitialPopup = {
                    'event_types': {
                        'event_type': {
                            'content': 'All Employee Meeting',
                            'id': '54750EAC957869B6E04031033A083365',
                            'color': '#FEEDDC'
                        }
                    },
                    'events': {
                        'event': 
                        [{
                            'start_date': '2016-07-16',
                            'calendars': '51C92673751653FCE04031033A083A9D'
                        }, {
                            'start_date': '2016-07-31',
                            'calendars': '51C92673751653FCE04031033A083A9D'
                        }, {
                            'start_date': '2016-07-02',
                            'calendars': '51C92673751653FCE04031033A083A9D'
                        }],
                        'no_result': 3
                    }
                },
                dataPopup = dataInitialPopup.events.event;

            $scope.eventDatesPopup = [];
            $scope.eventsPopup = dataPopup;

            $scope.loadEventsPopup = function (month, year, calendar) {
                if (data.length) {
                    $scope.filteredEventsPopup = $scope.events;
                    $scope.evtLengthPopup = data.length;
                    $scope.noEventClassPopup = '';
                    var i, stDay;
                    for (i = 0; i < data.length; i++) {
                        stDay = moment(data[i].start_date.replace(/\b(\d{1})\b/g, '0$1')).date();
                        $scope.eventDatesPopup.push(stDay);                        
                    } 
                } else {
                    $scope.calendarClass = 'calendarVisible';
                    //$scope.noEventClass = 'no-event';
                }
            };

            $scope.setMonthPopup(11, "Dec\'15", 2015);
        }]);
});
